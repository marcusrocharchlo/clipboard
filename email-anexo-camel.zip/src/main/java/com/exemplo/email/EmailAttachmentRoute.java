package com.exemplo.email;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class EmailAttachmentRoute extends RouteBuilder {

    private final EmailAttachmentService emailService;

    public EmailAttachmentRoute(EmailAttachmentService emailService) {
        this.emailService = emailService;
    }

    @Override
    public void configure() {
        from("scheduler://email-attachment-timer?delay=60000&useFixedDelay=true")
            .routeId("email-attachment-route")
            .log("Buscando anexos de e-mails...")
            .bean(emailService, "processEmailAttachments")
            .log("Anexos processados.");
    }
}
