package com.exemplo.email;

import com.microsoft.graph.models.*;
import com.microsoft.graph.requests.GraphServiceClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;

@Service
public class EmailAttachmentService {

    @Value("${outlook.user-id}")
    private String userId;

    @Value("${outlook.network-folder}")
    private String networkFolder;

    private final GraphServiceClient<?> graphClient;

    public EmailAttachmentService(GraphServiceClient<?> graphClient) {
        this.graphClient = graphClient;
    }

    public void processEmailAttachments() {
        var messages = graphClient.users(userId).mailFolders("Inbox").messages()
                .buildRequest()
                .filter("hasAttachments eq true")
                .top(5)
                .get()
                .getCurrentPage();

        for (Message message : messages) {
            List<Attachment> attachments = graphClient.users(userId).messages(message.id).attachments()
                    .buildRequest().get().getCurrentPage();

            for (Attachment attachment : attachments) {
                if (attachment instanceof FileAttachment fileAttachment) {
                    try {
                        Path targetPath = Paths.get(networkFolder, fileAttachment.name);
                        Files.write(targetPath, fileAttachment.contentBytes);
                        System.out.println("Arquivo salvo: " + targetPath);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
