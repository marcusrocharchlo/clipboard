package com.exemplo.camel;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.activation.DataHandler;
import java.io.*;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.IOUtils;

@Component
public class ZipAttachmentProcessor implements Processor {

    @Value("${output.folder}")
    private String outputFolder;

    @Override
    public void process(Exchange exchange) throws Exception {
        Map<String, DataHandler> attachments = exchange.getIn().getAttachments();

        for (Map.Entry<String, DataHandler> entry : attachments.entrySet()) {
            String fileName = entry.getKey();
            DataHandler handler = entry.getValue();

            if (fileName.toLowerCase().endsWith(".zip")) {
                try (InputStream zipStream = handler.getInputStream();
                     ZipInputStream zis = new ZipInputStream(zipStream)) {

                    ZipEntry zipEntry;
                    while ((zipEntry = zis.getNextEntry()) != null) {
                        if (!zipEntry.isDirectory()) {
                            File outputFile = new File(outputFolder, zipEntry.getName());
                            outputFile.getParentFile().mkdirs();

                            try (OutputStream os = new FileOutputStream(outputFile)) {
                                IOUtils.copy(zis, os);
                            }
                        }
                        zis.closeEntry();
                    }
                }
            }
        }
    }
}
