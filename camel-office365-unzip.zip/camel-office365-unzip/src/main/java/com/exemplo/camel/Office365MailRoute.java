package com.exemplo.camel;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Office365MailRoute extends RouteBuilder {

    private final Office365TokenService tokenService;
    private final Office365Properties properties;
    private final ZipAttachmentProcessor zipProcessor;

    public Office365MailRoute(Office365TokenService tokenService,
                              Office365Properties properties,
                              ZipAttachmentProcessor zipProcessor) {
        this.tokenService = tokenService;
        this.properties = properties;
        this.zipProcessor = zipProcessor;
    }

    @Override
    public void configure() {
        String accessToken = tokenService.getAccessToken();

        String uri = String.format(
            "imap://%s@outlook.office365.com"
            + "?mail.imaps.auth.mechanisms=XOAUTH2"
            + "&consumer.delay=60000"
            + "&searchTerm.unseen=true&peek=false"
            + "&fetchSize=10"
            + "&password=%s"
            + "&delete=false",
            properties.getUser(), accessToken
        );

        from(uri)
            .routeId("office365-email-unzip-attachments")
            .log("E-mail recebido: ${header.Subject}")
            .process(zipProcessor)
            .log("Anexos ZIP extraídos com sucesso.");
    }
}
