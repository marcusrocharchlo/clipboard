package com.exemplo.camel;

import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.junit.jupiter.api.Test;
import org.springframework.util.FileSystemUtils;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import java.io.File;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class ZipAttachmentProcessorTest {

    @Test
    public void testUnzipAttachment() throws Exception {
        String testDir = "target/test-output";
        new File(testDir).mkdirs();

        ZipAttachmentProcessor processor = new ZipAttachmentProcessor();
        processor.getClass().getDeclaredField("outputFolder").setAccessible(true);
        processor.getClass().getDeclaredField("outputFolder").set(processor, testDir);

        Exchange exchange = new DefaultExchange(new DefaultCamelContext());
        File zipFile = new File("src/test/resources/test.zip");
        exchange.getIn().setAttachments(Collections.singletonMap("test.zip", new DataHandler(new FileDataSource(zipFile))));

        processor.process(exchange);

        File extracted = new File(testDir + "/teste.txt");
        assertTrue(extracted.exists());

        // Cleanup
        FileSystemUtils.deleteRecursively(new File(testDir));
    }
}
